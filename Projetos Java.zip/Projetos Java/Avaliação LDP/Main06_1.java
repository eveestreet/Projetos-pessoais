import java.util.Scanner;
public class Main06_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o valor da refeição: ");
        double valorRefeicao = scanner.nextDouble();
        System.out.print("Digite a taxa de serviço (em %): ");
        double taxaServico = scanner.nextDouble();
        double valorTaxa = valorRefeicao * (taxaServico / 100);
        System.out.printf("O valor da taxa é: %.2f%n", valorTaxa);
        double valorTotal = valorRefeicao + valorTaxa;
        System.out.printf("O valor total da conta é: %.2f%n", valorTotal);
        scanner.close();

    }
}
