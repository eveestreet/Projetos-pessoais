import java.util.Scanner;
    public class Main05_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Digite a hora de início da partida (0-23): ");
        int horaInicio = sc.nextInt();
        System.out.print("Digite a hora de término da partida (0-23): ");
        int horaTermino = sc.nextInt();
        int duracao;
        System.out.print("A partida durou mais de 24 horas? (s/n): ");
        char resposta = sc.next().toLowerCase().charAt(0);
        if (resposta == 's') {
            System.out.println("A partida durou mais de 24 horas.");
        }else if (horaTermino > horaInicio) {
            duracao = horaTermino - horaInicio;
            System.out.println("A duração da partida foi de " + duracao + " horas.");
        } else {
            duracao = (24 - horaInicio) + horaTermino;
            System.out.println("A duração da partida foi de " + duracao + " horas.");
        }
    }
}
