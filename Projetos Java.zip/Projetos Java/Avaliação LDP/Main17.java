import java.util.Scanner;

public class Main17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o tipo de combustível abastecido (A-Álcool, G-Gasolina): ");
        String tipoCombustivel = scanner.nextLine().toUpperCase();
        System.out.println("Digite a quantidade de litros abastecidos: ");
        double litrosAbastecidos = scanner.nextDouble();
        double precoPorLitro;

        if (tipoCombustivel.equals("A")) {
            precoPorLitro = 2.90;
            double precoTotal = litrosAbastecidos * precoPorLitro;
            System.out.printf("O preço total a pagar é: R$ %.2f%n", precoTotal);
        } else if (tipoCombustivel.equals("G")) {
            precoPorLitro = 3.30;
            double precoTotal = litrosAbastecidos * precoPorLitro;
            System.out.printf("O preço total a pagar é: R$ %.2f%n", precoTotal);
        } else {
            System.out.println("Tipo de combustível inválido.");
        }
    }
}
