import java.util.Scanner;
    public class Main02 {
        public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite a hora atual (0-23): ");
        int hora = scanner.nextInt();
        System.out.println("Digite o minuto atual (0-59): ");
        int minuto = scanner.nextInt();
        System.out.println("Digite o segundo atual (0-59): ");
        int segundo = scanner.nextInt();
        int totalSegundos = hora * 3600 + minuto * 60 + segundo;
        System.out.println("O total de segundos é: " + totalSegundos);
        scanner.close();
        }
    
}
