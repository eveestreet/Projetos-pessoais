import java.util.Scanner;
    public class Main05_1 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Digite uma letra: ");
            char letra = scanner.next().toLowerCase().charAt(0);
            if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u') {
                System.out.println("A letra é uma vogal.");
            } else {
                System.out.println("A letra não é uma vogal.");
        }
    scanner.close();
    }
}
