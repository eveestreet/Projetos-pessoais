import java.util.Scanner;
public class Main16 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        }
    }
 //incompleto por incompetência do programador