import java.util.Scanner;
    public class Main{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o salário atual do empregado: ");
        double salarioAtual = scanner.nextDouble();
        System.out.print("Digite o percentual de aumento: ");
        double percentualAumento = scanner.nextDouble();
        double aumento = salarioAtual * (percentualAumento / 100);
        System.out.printf("O valor do aumento é: %.2f%n", aumento);
        double novoSalario = salarioAtual + aumento;
        System.out.printf("O novo salário do empregado é: %.2f%n", novoSalario);
        scanner.close();
    }
}
