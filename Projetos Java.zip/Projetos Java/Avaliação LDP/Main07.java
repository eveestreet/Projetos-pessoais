import java.util.Scanner;
public class Main07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o salário fixo do vendedor: ");
        double salarioFixo=  scanner.nextDouble();
        System.out.print("Digite a comissão fixa (em %): ");
        double comissaoFixa = scanner.nextDouble();
        System.out.print("Digite o total de vendas efetuadas pelo vendedor: ");
        double totalVendas = scanner.nextDouble();
        System.out.printf("O valor da comissão por carro vendido é: %.2f%n", comissaoFixa * totalVendas / 100);
        double salarioFinal = salarioFixo + (comissaoFixa * totalVendas / 100) + (totalVendas * 0.05);
        System.out.printf("O salário final do vendedor é: %.2f%n", salarioFinal);
        scanner.close();
}
}