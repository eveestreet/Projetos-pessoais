import java.util.Scanner;

public class Main14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o preço original do produto: ");
        double precoOriginal = scanner.nextDouble();

        System.out.println("Digite o desconto em porcentagem: ");

        double descontoPercentual = scanner.nextDouble();
        double valorDesconto = (descontoPercentual / 100) * precoOriginal;
        double precoFinal = precoOriginal - valorDesconto;

        System.out.printf("O preço final do produto com desconto é: R$ %.2f%n", precoFinal);
        scanner.close();
    }

}
