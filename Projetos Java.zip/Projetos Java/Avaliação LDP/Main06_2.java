import java.util.Scanner;
public class Main06_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o custo de fábrica do carro: ");
        double custoFabrica = scanner.nextDouble();
        double percentualDistribuidor = custoFabrica * 0.28;
        System.out.printf("O custo do distribuidor é: %.2f%n", percentualDistribuidor);
        double impostos = custoFabrica * 0.45;
        System.out.printf("O valor dos impostos é: %.2f%n", impostos);
        double custoFinal = custoFabrica + percentualDistribuidor + impostos;
        System.out.printf("O custo final do carro é: %.2f%n", custoFinal);
        scanner.close();
    }
}