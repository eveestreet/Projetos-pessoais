import java.util.*;

public class Main09 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite um número inteiro positivo: ");
        int numero = scanner.nextInt();
        if (numero % 5 == 0) {
            System.out.println("O número " + numero + " é múltiplo de 5.");
        } else {
            System.out.println("O número " + numero + " não é múltiplo de 5.");
        }
        scanner.close();
    }
    
}
