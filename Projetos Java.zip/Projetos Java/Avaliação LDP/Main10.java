import java.util.Scanner;

public class Main10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite uma letra: ");
        char letra = scanner.next().charAt(0);
        if (Character.isUpperCase(letra)) {
            System.out.println("A letra '" + letra + "' é maiúscula.");
        } else {
            System.out.println("A letra '" + letra + "' é minúscula.");
        }
    }
}