import java.util.Scanner;

public class Main08 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o ano atual: ");
        int anoAtual = scanner.nextInt();
        System.out.println("Digite a quantidade de dias no ano (365 ou 366): ");
        int diasAno = scanner.nextInt();

        if (diasAno == 365) {
            System.out.println("O ano de " + anoAtual + " é um ano comum.");
        } else if (diasAno == 366) {
            System.out.println("O ano de " + anoAtual + " é um ano bissexto.");
        } else {
            System.out.println("'" + diasAno + "' " + "é um valor inválido para a quantidade de dias no ano.");
        }
    }
}
