import java.util.Scanner;

public class Main12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite a quantidade atual do produto em estoque: ");
        int quantidadeAtual = scanner.nextInt();
        System.out.println("Digite a quantidade mínima do produto em estoque: ");
        int quantidadeMinima = scanner.nextInt();
        System.out.println("Digite a quantidade máxima do produto em estoque: ");
        int quantidadeMaxima = scanner.nextInt();
        int media = (quantidadeMaxima + quantidadeMinima) / 2;
        System.out.println("Quantidade média é: " + media);
        if (quantidadeAtual >= media) {
            System.out.println("Não efetuar compra do produto.");
        } else {
            System.out.println("Efetuar compra do produto.");
        }
        scanner.close();
    }

}