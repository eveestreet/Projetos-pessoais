import java.util.Scanner;
public class PerimetroTriangulo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o comprimento do lado A: ");
        int ladoA = scanner.nextInt();

        System.out.print("Digite o comprimento do lado B: ");
        int ladoB = scanner.nextInt();

        System.out.print("Digite o comprimento do lado C: ");
        int ladoC = scanner.nextInt();

        int perimetro = ladoA + ladoB + ladoC;

        System.out.println("O perímetro do triângulo é: " + perimetro);

        scanner.close();
    }
    
}
