import java.util.Scanner;
    public class Compras{

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o preço unitário do produto: ");
        double precoUnitario = scanner.nextDouble();

        System.out.print("Digite a quantidade comprada: ");
        int quantidade = scanner.nextInt();

        double totalCompra = precoUnitario * quantidade;

        System.out.printf("Total da compra: R$ %.2f%n", totalCompra);

        scanner.close();
    }
}