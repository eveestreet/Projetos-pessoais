import java.util.Scanner;
public class SalarioFuncionario {
    public static void main(String[]args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o número de horas trabalhadas no mês:");
        int horasTrabalhadas = scanner.nextInt();

        System.out.println("Digite o salário mensal:");
        double salarioMensal= scanner.nextDouble();
        double salarioPorHora = salarioMensal / 160;
        double salarioTotal;
        if (horasTrabalhadas > 160) {
            int horasExtras = horasTrabalhadas - 160;
            double valorHoraExtra = salarioPorHora * 0.05;
            salarioTotal = (160 * salarioPorHora) + (horasExtras * valorHoraExtra);
            System.out.println("Horas extras trabalhadas: " + horasExtras);
            System.out.printf("O salário total com acréscimo de 5 porcento é de: R$ %.2f%n", salarioTotal);
        } else {
            salarioTotal = horasTrabalhadas * salarioPorHora;
            System.out.printf("O salário total do funcionário é: R$ %.2f%n", salarioTotal);
        }
        scanner.close();
    }
    
}
