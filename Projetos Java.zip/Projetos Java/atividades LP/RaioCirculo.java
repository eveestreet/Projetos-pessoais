import java.util.Scanner;
public class RaioCirculo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor do raio do círculo: ");
        double raio = scanner.nextDouble();
        double area = Math.PI * Math.pow(raio, 2);

        System.out.printf("A área do círculo é: %.2f%n", area);

        scanner.close();
    }
    
}
