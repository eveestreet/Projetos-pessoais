import java.util.Scanner;
    public class JurosSimples {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Digite o valor do capital inicial (P): ");
                double P = sc.nextDouble();
            System.out.print("Digite a taxa de juros anual (r) em decimal (ex: 0,05 para 5%): ");
                double r = sc.nextDouble();
            System.out.print("Digite o número de anos (n): ");
                int n = sc.nextInt();
                double M = P * Math.pow((1 + r), n);
            System.out.printf("O montante final (M) é: %.2f", M);
            sc.close();
        }
    }