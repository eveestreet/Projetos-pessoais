import java.util.Scanner;
public class ConversaoCambial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor em reais (R$): ");
        double valorReais = scanner.nextDouble();
        double valorDolares = valorReais / 5.05;

        System.out.printf("O valor em dólares (US$) é: %.2f%n", valorDolares);

        scanner.close();
    }
}