import java.util.Scanner;
public class Comissao {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor total das vendas: ");
        double valorVendas = scanner.nextDouble();
        if (valorVendas >= 1500) {
        double comissao = valorVendas * 0.05;
        System.out.printf("O valor da comissão é: R$ %.2f%n", comissao);
        } else {
        double comissao = valorVendas * 0.03;

        System.out.printf("O valor da comissão é: R$ %.2f%n", comissao);
        }

        scanner.close();
    }
}